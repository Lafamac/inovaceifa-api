package com.inovaceifa.api.repository;

import com.inovaceifa.api.model.PerfilUsuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PerfilUsuarioRepository
        extends JpaRepository<PerfilUsuario, Integer> {
}

